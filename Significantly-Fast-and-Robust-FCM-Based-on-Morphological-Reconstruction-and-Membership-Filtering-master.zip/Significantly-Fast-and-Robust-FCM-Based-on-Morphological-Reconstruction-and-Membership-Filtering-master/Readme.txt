
Please cite the paper 

T. Lei, X. Jia, Y. Zhang, L. He, H. Meng and A. K. Nandi, "Significantly Fast and Robust Fuzzy C-Means Clustering Algorithm Based on Morphological Reconstruction and Membership Filtering," in IEEE Transactions on Fuzzy Systems, vol. PP, no. 99, pp. 1-1.doi: 10.1109/TFUZZ.2018.2796074

Full paper link: http://ieeexplore.ieee.org/stamp/stamp.jsp?arnumber=8265186 

1. If you want to segment a gray image, please run main_gray.
2. If you want to segment a color image, please run main_color.