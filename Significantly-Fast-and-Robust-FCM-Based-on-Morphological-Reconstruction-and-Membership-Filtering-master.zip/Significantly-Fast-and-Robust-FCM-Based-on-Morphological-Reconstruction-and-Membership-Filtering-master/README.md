# Image-segmentation-using-fast-fuzzy-c-means-clusering
A fast and robust fuzzy c-means clustering algorithms, namely FRFCM, is proposed. The FRFCM is able to segment grayscale and color images and provides excellent segmentation results.

This paper has been accepted for publication in the IEEE Transactions on Fuzzy Systems.
